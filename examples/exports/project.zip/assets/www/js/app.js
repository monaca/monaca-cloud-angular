var app = angular.module('myApp', [ 'ngTouch', 'onsen.directives', 'monaca.cloud']);


app.controller('MainCtrl', function($scope, MonacaBackend) {
  $scope.result = null;
  $scope.error = null;
  
  var now = Date.now();
  $scope.username = 'user' + now;
  $scope.password = 'pass';
  
  $scope.signup = function() {
    console.log($scope.username);
    console.log($scope.password);
    MonacaBackend.User.register(
      $scope.username, $scope.password  
    ).then(
      function(result) {
        console.log(JSON.stringify(result));
        $scope.result = result;
      },
      function(error) {
        console.log(JSON.stringify(error));
        $scope.error = error;
      }
    );
  };
});
